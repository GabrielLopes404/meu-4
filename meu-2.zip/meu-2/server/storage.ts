import {
  type PortfolioItem,
  type InsertPortfolioItem,
  type Service,
  type InsertService,
  type Testimonial,
  type InsertTestimonial,
  type Faq,
  type InsertFaq,
  type BeforeAfter,
  type InsertBeforeAfter,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getPortfolioItems(): Promise<PortfolioItem[]>;
  getServices(): Promise<Service[]>;
  getTestimonials(): Promise<Testimonial[]>;
  getFaqs(): Promise<Faq[]>;
  getBeforeAfter(): Promise<BeforeAfter[]>;
}

export class MemStorage implements IStorage {
  private portfolioItems: Map<string, PortfolioItem>;
  private services: Map<string, Service>;
  private testimonials: Map<string, Testimonial>;
  private faqs: Map<string, Faq>;
  private beforeAfter: Map<string, BeforeAfter>;

  constructor() {
    this.portfolioItems = new Map();
    this.services = new Map();
    this.testimonials = new Map();
    this.faqs = new Map();
    this.beforeAfter = new Map();
    
    this.seedData();
  }

  private seedData() {
    const services: InsertService[] = [
      {
        title: "Identidade Visual",
        description: "Identidade visual forte, moderna e memorável pra sua marca se destacar.",
        icon: "palette",
      },
      {
        title: "Artes para Mídias",
        description: "Criações impactantes que atraem, comunicam e vendem mais.",
        icon: "image",
      },
      {
        title: "Personagens 3D",
        description: "Modelagens únicas e originais para dar vida à sua ideia ou marca.",
        icon: "box",
      },
      {
        title: "Sites e Aplicativos",
        description: "Designs completos, bonitos e funcionais prontos para usar em projetos digitais.",
        icon: "monitor",
      },
      {
        title: "Projetos sob Medida",
        description: "Tudo que sua marca precisa em um só lugar: qualidade, agilidade e preço justo.",
        icon: "sparkles",
      },
    ];

    services.forEach((service) => {
      const id = randomUUID();
      this.services.set(id, { ...service, id });
    });

    const portfolioItems: InsertPortfolioItem[] = [
      {
        title: "Logo Moderna Tech Startup",
        category: "Identidade Visual",
        imageUrl: "https://images.unsplash.com/photo-1626785774625-ddcddc3445e9?w=800&h=800&fit=crop",
        description: "Identidade visual completa para startup de tecnologia",
        client: "TechVision",
        order: 1,
      },
      {
        title: "Branding Café Artesanal",
        category: "Identidade Visual",
        imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&h=800&fit=crop",
        description: "Logo e materiais gráficos para cafeteria premium",
        client: "Café Aromas",
        order: 2,
      },
      {
        title: "Post Instagram Promoção",
        category: "Social Media",
        imageUrl: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&h=800&fit=crop",
        description: "Arte promocional para redes sociais",
        client: "Loja Fashion",
        order: 3,
      },
      {
        title: "Feed Instagram Harmonizado",
        category: "Social Media",
        imageUrl: "https://images.unsplash.com/photo-1611926653458-09294b3142bf?w=800&h=800&fit=crop",
        description: "Grid completo para Instagram com identidade visual",
        client: "Beauty Studio",
        order: 4,
      },
      {
        title: "Mascote 3D Personagem",
        category: "3D",
        imageUrl: "https://images.unsplash.com/photo-1633613286991-611fe299c4be?w=800&h=800&fit=crop",
        description: "Modelagem 3D de mascote corporativo",
        client: "Kids Club",
        order: 5,
      },
      {
        title: "Produto 3D Render",
        category: "3D",
        imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&h=800&fit=crop",
        description: "Renderização 3D para catálogo de produtos",
        client: "Design Store",
        order: 6,
      },
      {
        title: "Landing Page Moderna",
        category: "Web/App",
        imageUrl: "https://images.unsplash.com/photo-1547658718-1cdaa0852790?w=800&h=800&fit=crop",
        description: "Design de landing page responsiva e moderna",
        client: "SaaS Company",
        order: 7,
      },
      {
        title: "Interface App Mobile",
        category: "Web/App",
        imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&h=800&fit=crop",
        description: "UI/UX design para aplicativo mobile",
        client: "Fitness App",
        order: 8,
      },
      {
        title: "Cartão de Visita Premium",
        category: "Identidade Visual",
        imageUrl: "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=800&h=800&fit=crop",
        description: "Cartão de visita elegante e profissional",
        client: "Advocacia Silva",
        order: 9,
      },
      {
        title: "Banner Evento Corporativo",
        category: "Social Media",
        imageUrl: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800&h=800&fit=crop",
        description: "Arte para divulgação de evento empresarial",
        client: "CongressTech 2025",
        order: 10,
      },
      {
        title: "Embalagem Produto",
        category: "Identidade Visual",
        imageUrl: "https://images.unsplash.com/photo-1612528443702-f6741f70a049?w=800&h=800&fit=crop",
        description: "Design de embalagem para linha de produtos",
        client: "Organic Foods",
        order: 11,
      },
      {
        title: "Stories Animados",
        category: "Social Media",
        imageUrl: "https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=800&h=800&fit=crop",
        description: "Template de stories para Instagram",
        client: "Influencer Digital",
        order: 12,
      },
    ];

    portfolioItems.forEach((item) => {
      const id = randomUUID();
      this.portfolioItems.set(id, { ...item, id });
    });

    const testimonials: InsertTestimonial[] = [
      {
        author: "Riquelme Fontes",
        text: "Eu já tinha tentado com outros designers antes, mas ninguém conseguiu captar o estilo da minha marca como ele fez. Além de criativo, entrega no prazo e está sempre disponível pra ajustes. Sério, fiquei impressionado com o resultado final!",
        avatarUrl: null,
      },
      {
        author: "Amanda Alves",
        text: "Eu só tinha uma ideia vaga na cabeça e ele conseguiu transformar tudo em uma marca profissional, com uma logo que representa exatamente o que eu queria. Foi rápido, atencioso e acertou de primeira. Recomendo de olhos fechados!",
        avatarUrl: null,
      },
      {
        author: "Breno Manzano",
        text: "Profissionalismo do início ao fim! O Lopes não só criou um design incrível, como também entendeu perfeitamente o que eu precisava para o meu negócio. Entrega rápida e resultado impecável. Já estou planejando o próximo projeto com ele!",
        avatarUrl: null,
      },
      {
        author: "Francisco Neto",
        text: "Trabalho excepcional! A identidade visual que ele criou para minha empresa superou todas as expectativas. Muito criativo, profissional e dedicado. Sem dúvida, o melhor designer que já contratei!",
        avatarUrl: null,
      },
    ];

    testimonials.forEach((testimonial) => {
      const id = randomUUID();
      this.testimonials.set(id, { ...testimonial, id });
    });

    const faqs: InsertFaq[] = [
      {
        question: "❓ Quanto tempo leva para entregar um projeto?",
        answer: "Depende do tipo de arte. Logos e banners simples levam de 1 a 3 dias. Projetos mais completos, como personagens 3D ou pacotes para apps e sites, podem levar de 5 a 10 dias. Sempre passo o prazo certinho antes de começar.",
        order: 1,
      },
      {
        question: "❓ Posso pedir alterações depois da entrega?",
        answer: "Sim! Todos os projetos incluem um número de revisões gratuitas, para garantir que o resultado fique exatamente como você quer. O importante é você sair satisfeito.",
        order: 2,
      },
      {
        question: "❓ Você trabalha com urgência?",
        answer: "Sim, dependendo da demanda do momento. Projetos com urgência têm uma pequena taxa adicional, mas consigo priorizar e entregar o quanto antes com a mesma qualidade.",
        order: 3,
      },
      {
        question: "❓ É verdade que só pago depois que a arte estiver pronta?",
        answer: "Sim! Todas as artes são feitas com pagamento somente após a entrega. Você só paga depois de ver, aprovar e ficar satisfeito com o resultado. Sem riscos, sem surpresas — confio tanto no meu trabalho que coloco sua confiança em primeiro lugar.",
        order: 4,
      },
    ];

    faqs.forEach((faq) => {
      const id = randomUUID();
      this.faqs.set(id, { ...faq, id });
    });

    const beforeAfterItems: InsertBeforeAfter[] = [
      {
        title: "Logo Creche Infantil",
        client: "Creche Pequenos Sonhos",
        beforeImageUrl: "/attached_assets/image_1763748532044.png",
        afterImageUrl: "/attached_assets/Logo 1_1763748541496.png",
        order: 1,
      },
    ];

    beforeAfterItems.forEach((item) => {
      const id = randomUUID();
      this.beforeAfter.set(id, { ...item, id });
    });
  }

  async getPortfolioItems(): Promise<PortfolioItem[]> {
    return Array.from(this.portfolioItems.values()).sort((a, b) => a.order - b.order);
  }

  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }

  async getFaqs(): Promise<Faq[]> {
    return Array.from(this.faqs.values()).sort((a, b) => a.order - b.order);
  }

  async getBeforeAfter(): Promise<BeforeAfter[]> {
    return Array.from(this.beforeAfter.values()).sort((a, b) => a.order - b.order);
  }
}

export const storage = new MemStorage();
