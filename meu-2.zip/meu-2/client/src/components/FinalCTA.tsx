import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import { SiInstagram } from "react-icons/si";

export function FinalCTA() {
  return (
    <section className="py-24 md:py-32 bg-card relative overflow-hidden" data-testid="section-final-cta">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1a1a1a_1px,transparent_1px),linear-gradient(to_bottom,#1a1a1a_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30" />
      
      <div className="absolute top-0 left-0 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight leading-tight" data-testid="text-finalcta-title">
              Vamos dar vida ao <span className="text-primary">seu projeto</span>
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-finalcta-description">
              Transforme sua ideia em realidade. Entre em contato agora e receba uma resposta personalizada em até 24 horas.
            </p>
          </div>

          <div className="flex flex-col items-start lg:items-end gap-4">
            <a
              href="https://www.instagram.com/lopesdesigner_ofc/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full lg:w-auto"
              data-testid="button-final-cta"
            >
              <Button size="lg" className="w-full lg:w-auto text-base px-8 py-6 relative overflow-hidden group">
                <span className="relative z-10 flex items-center gap-3">
                  <Sparkles className="w-5 h-5" />
                  PEDIR MEU PROJETO PERSONALIZADO
                  <SiInstagram className="w-5 h-5" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0 opacity-0 group-hover:opacity-100 transition-opacity" />
              </Button>
            </a>
            <p className="text-sm text-muted-foreground" data-testid="text-finalcta-response-time">
              <span className="text-primary font-semibold">Resposta em até 24h</span> • Orçamento sem compromisso
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
