import { useState, useEffect, useRef } from "react";
import { Eye, Sparkles, Box, Video, Zap } from "lucide-react";

export function Differentiators() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      icon: Eye,
      title: "Identidade Visual",
      description: "Identidade visual forte, moderna e memorável pra sua marca se destacar.",
      angle: -45,
    },
    {
      icon: Sparkles,
      title: "Peças para Mídias",
      description: "Criações impactantes que atraem, comunicam e vendem mais.",
      angle: 45,
    },
    {
      icon: Box,
      title: "Modelagem 3D",
      description: "Modelagens únicas e originais para dar vida à sua ideia ou marca.",
      angle: -135,
    },
    {
      icon: Video,
      title: "Pacote Audiovisual",
      description: "Designs completos, bonitos e funcionais prontos para usar em projetos digitais.",
      angle: 135,
    },
    {
      icon: Zap,
      title: "Edições para Internet",
      description: "Tudo que sua marca precisa em um só lugar: qualidade, agilidade e preço justo.",
      angle: 180,
    },
  ];

  return (
    <section ref={sectionRef} className="py-20 md:py-32 bg-[#0a0012] relative overflow-hidden" data-testid="section-differentiators">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-primary/5 to-transparent"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0a0012]"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/40 mb-4 shadow-[0_0_20px_rgba(236,72,153,0.3)]">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary uppercase tracking-wider">Meus Serviços</span>
          </div>
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight text-white">
            O que eu <span className="text-primary">faço</span>
          </h2>
        </div>

        <div className="hidden md:block">
          <div className="relative max-w-5xl mx-auto min-h-[700px] flex items-center justify-center">
            <div className="relative w-full h-[700px]">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-gradient-to-br from-primary/30 via-primary/20 to-primary/10 blur-3xl"></div>
              
              <div 
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full border-[2px] border-primary/20 opacity-40"
                style={{
                  animation: isVisible ? 'pulse 8s ease-in-out infinite' : 'none'
                }}
              ></div>
              
              <div 
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full border-[2px] border-primary/30 opacity-50"
                style={{
                  animation: isVisible ? 'pulse 6s ease-in-out infinite 0.5s' : 'none'
                }}
              ></div>
              
              <div 
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full border-[2px] border-primary/40 opacity-60"
                style={{
                  animation: isVisible ? 'pulse 4s ease-in-out infinite 1s' : 'none'
                }}
              ></div>
              
              <div 
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[240px] h-[240px] rounded-full bg-black flex items-center justify-center ring-4 ring-primary/50 shadow-[0_0_80px_rgba(236,72,153,0.6)] overflow-hidden"
              >
                <div className="w-[220px] h-[220px] rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-2xl overflow-hidden">
                  <img 
                    src="/attached_assets/image_1763746186609.png" 
                    alt="Design 3D" 
                    className="w-full h-full object-cover scale-150"
                    style={{
                      animation: isVisible ? 'spin 20s linear infinite' : 'none'
                    }}
                  />
                </div>
              </div>

              {services.map((service, index) => {
                const radius = 280;
                const angleInRadians = (service.angle * Math.PI) / 180;
                const x = Math.cos(angleInRadians) * radius;
                const y = Math.sin(angleInRadians) * radius;

                return (
                  <div
                    key={index}
                    className="absolute top-1/2 left-1/2"
                    style={{
                      transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
                    }}
                    data-testid={`card-differentiator-${index}`}
                  >
                    <div 
                      className="group relative -translate-x-1/2 -translate-y-1/2"
                      style={{
                        animation: isVisible ? `floatCard 3s ease-in-out infinite ${index * 0.2}s` : 'none',
                      }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-primary/10 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
                      <div className="relative bg-gradient-to-br from-[#1a0a28] via-[#0f0518] to-[#1f0a30] backdrop-blur-sm border-[1.5px] border-primary/40 rounded-2xl p-6 shadow-[0_0_30px_rgba(236,72,153,0.35)] hover:shadow-[0_0_50px_rgba(236,72,153,0.5)] transition-all duration-300 hover:scale-105 w-[240px]">
                        <div className="flex items-start gap-3 mb-3">
                          <div className="flex-shrink-0 w-10 h-10 rounded-full bg-black border-[1.5px] border-primary/50 flex items-center justify-center shadow-lg">
                            <service.icon className="w-5 h-5 text-primary" />
                          </div>
                          <h3 className="font-display font-bold text-lg leading-tight text-white" data-testid={`text-differentiator-title-${index}`}>
                            {service.title}
                          </h3>
                        </div>
                        <p className="text-sm text-white/70 leading-relaxed" data-testid={`text-differentiator-desc-${index}`}>
                          {service.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="md:hidden grid grid-cols-1 gap-6 max-w-md mx-auto">
          {services.map((service, index) => (
            <div
              key={index}
              className="group relative"
              style={{
                animation: isVisible ? `fadeInUp 0.6s ease-out ${index * 0.1}s both` : 'none'
              }}
              data-testid={`card-differentiator-${index}`}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-primary/10 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
              <div className="relative bg-gradient-to-br from-[#1a0a28] via-[#0f0518] to-[#1f0a30] backdrop-blur-sm border-[1.5px] border-primary/40 rounded-2xl p-6 shadow-[0_0_30px_rgba(236,72,153,0.35)] hover:shadow-[0_0_50px_rgba(236,72,153,0.5)] transition-all duration-300 hover:scale-105">
                <div className="flex items-start gap-4 mb-3">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-black border-[1.5px] border-primary/50 flex items-center justify-center shadow-lg">
                    <service.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-display font-bold text-xl leading-tight text-white" data-testid={`text-differentiator-title-${index}`}>
                    {service.title}
                  </h3>
                </div>
                <p className="text-sm text-white/70 leading-relaxed" data-testid={`text-differentiator-desc-${index}`}>
                  {service.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
