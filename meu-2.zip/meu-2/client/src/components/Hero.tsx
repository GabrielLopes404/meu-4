import { Button } from "@/components/ui/button";
import { ArrowDown, Sparkles, Code2, Palette } from "lucide-react";

export function Hero() {
  const scrollToPortfolio = () => {
    const element = document.getElementById("portfolio");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#050505]" data-testid="section-hero">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
      
      <div className="absolute top-1/4 left-[10%] w-96 h-96 bg-primary/30 rounded-full blur-[140px] animate-float" />
      <div className="absolute bottom-1/4 right-[10%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-[160px] animate-float" style={{ animationDelay: "-4s" }} />
      
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-4xl opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#ff00c8_0%,transparent_70%)]"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20 text-center">
        <div className="space-y-10">
          <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/40 shadow-[0_0_30px_rgba(236,72,153,0.3)] mb-6">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-primary" />
              <span className="text-white/90 text-sm font-medium">Design Gráfico</span>
            </div>
            <div className="w-1 h-4 bg-primary/40"></div>
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-primary" />
              <span className="text-white/90 text-sm font-medium">Desenvolvimento Web</span>
            </div>
          </div>

          <div className="space-y-6">
            <h1 className="font-display font-black text-6xl sm:text-7xl md:text-8xl lg:text-[10rem] tracking-tight leading-none" data-testid="text-hero-title">
              <span className="block text-white uppercase drop-shadow-2xl" style={{ letterSpacing: "-0.03em" }}>
                LOPES
              </span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-pink-500 to-primary uppercase relative" style={{ letterSpacing: "-0.03em" }}>
                DESIGNER
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-48 h-1.5 bg-gradient-to-r from-transparent via-primary to-transparent shadow-[0_0_20px_rgba(236,72,153,0.8)]" />
              </span>
            </h1>
          </div>

          <p className="max-w-3xl mx-auto text-xl sm:text-2xl text-white/70 font-body leading-relaxed" data-testid="text-hero-subtitle">
            Transformo marcas com <span className="text-primary font-bold">design estratégico</span> e{" "}
            <span className="text-primary font-bold">sites profissionais</span> que atraem, encantam e convertem.
            <br />
            <span className="text-white/50 text-lg mt-3 block">
              Mais de <span className="text-primary font-semibold">350 projetos</span> entregues com excelência.
            </span>
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-5 pt-8">
            <a
              href="https://www.instagram.com/lopesdesigner_ofc/"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="button-cta-hero"
            >
              <Button size="lg" className="text-base px-10 py-7 bg-gradient-to-r from-primary to-pink-600 hover:from-pink-600 hover:to-primary relative overflow-hidden group shadow-[0_0_40px_rgba(236,72,153,0.5)] hover:shadow-[0_0_60px_rgba(236,72,153,0.8)] transition-all border-0">
                <span className="relative z-10 flex items-center gap-3 font-bold uppercase tracking-wide">
                  <Sparkles className="w-5 h-5" />
                  SOLICITAR MEU PROJETO
                </span>
                <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              </Button>
            </a>
            <button
              onClick={scrollToPortfolio}
              className="px-10 py-7 text-base font-bold text-white border-2 border-white/20 hover:border-primary/60 rounded-lg transition-all hover:bg-white/5 backdrop-blur-sm uppercase tracking-wide"
            >
              VER PORTFOLIO
            </button>
          </div>

          <div className="pt-16">
            <button
              onClick={scrollToPortfolio}
              className="inline-flex flex-col items-center gap-2 text-white/50 hover:text-primary transition-colors group"
              data-testid="button-scroll-down"
            >
              <span className="text-xs uppercase tracking-widest font-semibold">Descubra meu trabalho</span>
              <ArrowDown className="w-6 h-6 animate-bounce group-hover:text-primary" />
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#050505] to-transparent pointer-events-none"></div>
    </section>
  );
}
