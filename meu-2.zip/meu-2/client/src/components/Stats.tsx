import { useEffect, useRef, useState } from "react";
import { TrendingUp, Award, Clock, ChevronRight } from "lucide-react";

export function Stats() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const stats = [
    {
      icon: TrendingUp,
      value: 350,
      suffix: "+",
      label: "Projetos Entregues",
      description: "Com qualidade comprovada",
    },
    {
      icon: Award,
      value: 100,
      suffix: "%",
      label: "Aprovado por Todos",
      description: "Satisfação garantida",
    },
    {
      icon: Clock,
      value: 5,
      suffix: "+",
      label: "Anos de Experiência",
      description: "Expertise consolidada",
    },
  ];

  function AnimatedNumber({ value, suffix }: { value: number; suffix: string }) {
    const [count, setCount] = useState(0);

    useEffect(() => {
      if (!isVisible) return;

      const duration = 2000;
      const steps = 60;
      const increment = value / steps;
      let current = 0;

      const timer = setInterval(() => {
        current += increment;
        if (current >= value) {
          setCount(value);
          clearInterval(timer);
        } else {
          setCount(Math.floor(current));
        }
      }, duration / steps);

      return () => clearInterval(timer);
    }, [isVisible, value]);

    return (
      <span>
        {count}
        {suffix}
      </span>
    );
  }

  return (
    <section ref={sectionRef} className="py-20 bg-gradient-to-b from-background via-background/95 to-background relative overflow-hidden" data-testid="section-stats">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="relative -mx-4 md:mx-0">
          <div className="md:hidden absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-background via-background/80 to-transparent z-10 pointer-events-none flex items-center justify-start pl-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center animate-pulse">
              <ChevronRight className="w-5 h-5 text-primary" />
            </div>
          </div>
          <div className="md:hidden absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-background via-background/80 to-transparent z-10 pointer-events-none flex items-center justify-end pr-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center animate-pulse">
              <ChevronRight className="w-5 h-5 text-primary" />
            </div>
          </div>
          <div className="md:grid md:grid-cols-3 md:gap-16 flex overflow-x-auto gap-8 pb-4 snap-x snap-mandatory scrollbar-hide scroll-smooth-touch px-4 md:px-0">
            {stats.map((stat, index) => (
            <div
              key={index}
              className="text-center space-y-4 group min-w-[80vw] md:min-w-0 snap-center flex-shrink-0"
              style={{
                animation: isVisible ? `fadeInUp 0.6s ease-out ${index * 0.15}s both` : 'none'
              }}
              data-testid={`stat-${index}`}
            >
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border border-primary/20 group-hover:border-primary/40 group-hover:shadow-[0_0_30px_rgba(236,72,153,0.3)] transition-all duration-500 mb-6 relative">
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/5 to-transparent group-hover:scale-110 transition-transform duration-500"></div>
                <stat.icon className="w-10 h-10 text-primary relative z-10 group-hover:scale-110 transition-transform duration-500" />
              </div>
              
              <div className="font-display font-bold text-5xl md:text-6xl lg:text-7xl bg-gradient-to-br from-primary via-primary to-primary/80 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(236,72,153,0.3)]" data-testid={`text-stat-value-${index}`}>
                <AnimatedNumber value={stat.value} suffix={stat.suffix} />
              </div>
              
              <div className="space-y-2">
                <div className="font-display font-bold text-xl uppercase tracking-wide" data-testid={`text-stat-label-${index}`}>
                  {stat.label}
                </div>
                <div className="text-sm text-muted-foreground" data-testid={`text-stat-desc-${index}`}>
                  {stat.description}
                </div>
              </div>
            </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
