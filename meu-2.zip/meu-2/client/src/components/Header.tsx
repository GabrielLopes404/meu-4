import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { SiInstagram } from "react-icons/si";
import { Sparkles } from "lucide-react";

export function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-background/80 backdrop-blur-md border-b border-border" : "bg-transparent"
      }`}
      data-testid="header-main"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-2" data-testid="logo-container">
            <img 
              src="/attached_assets/image_1763748592137.png" 
              alt="Lopes Designer" 
              className="h-12 w-auto"
            />
          </div>

          <nav className="hidden md:flex items-center gap-6" data-testid="nav-main">
            <button
              onClick={() => scrollToSection("servicos")}
              className="text-sm font-semibold uppercase tracking-wide text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-services"
            >
              Design
            </button>
            <button
              onClick={() => scrollToSection("web-development")}
              className="text-sm font-semibold uppercase tracking-wide text-muted-foreground hover:text-blue-500 transition-colors"
              data-testid="link-web"
            >
              Sites
            </button>
            <button
              onClick={() => scrollToSection("traffic")}
              className="text-sm font-semibold uppercase tracking-wide text-muted-foreground hover:text-green-500 transition-colors"
              data-testid="link-traffic"
            >
              Tráfego
            </button>
            <button
              onClick={() => scrollToSection("portfolio")}
              className="text-sm font-semibold uppercase tracking-wide text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-portfolio"
            >
              Portfolio
            </button>
            <button
              onClick={() => scrollToSection("depoimentos")}
              className="text-sm font-semibold uppercase tracking-wide text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-testimonials"
            >
              Depoimentos
            </button>
          </nav>

          <a
            href="https://www.instagram.com/lopesdesigner_ofc/"
            target="_blank"
            rel="noopener noreferrer"
            data-testid="button-cta-header"
          >
            <Button className="relative overflow-hidden group" size="default">
              <span className="relative z-10 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span className="hidden sm:inline">Solicitar Projeto</span>
                <SiInstagram className="w-4 h-4 sm:hidden" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary to-primary opacity-0 group-hover:opacity-20 transition-opacity" />
            </Button>
          </a>
        </div>
      </div>
    </header>
  );
}
